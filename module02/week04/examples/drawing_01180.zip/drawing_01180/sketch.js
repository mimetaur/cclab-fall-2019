// wall drawing #1180

function setup() {
  createCanvas(600, 600);

  noLoop();
}

function draw() {
  background(250);
}
